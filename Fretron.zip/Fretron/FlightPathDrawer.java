import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FlightPathDrawer extends JPanel {
    private final BufferedImage canvas;
    private final List<List<Point>> flightPaths;
    private final List<Color> colors;
    private Graphics2D g2d;
    
    public FlightPathDrawer() {
        this.flightPaths = new ArrayList<>();
        this.colors = new ArrayList<>();
        this.canvas = new BufferedImage(800, 800, BufferedImage.TYPE_INT_ARGB);
        this.g2d = canvas.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    private void drawPaths() {
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());

        Random random = new Random();
        colors.clear();

        List<List<Point>> adjustedPaths = adjustPaths(flightPaths);

        for (List<Point> path : adjustedPaths) {
            Color color = new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256));
            colors.add(color);
            g2d.setColor(color);
            g2d.setStroke(new BasicStroke(2));
            for (int i = 0; i < path.size() - 1; i++) {
                Point p1 = path.get(i);
                Point p2 = path.get(i + 1);
                g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
            g2d.setColor(color.darker());
            for (Point p : path) {
                g2d.fillOval(p.x - 5, p.y - 5, 10, 10);
            }
        }
    }

    private List<List<Point>> adjustPaths(List<List<Point>> paths) {
        List<List<Point>> adjustedPaths = new ArrayList<>();
        for (List<Point> path : paths) {
            List<Point> adjustedPath = new ArrayList<>(path);
            adjustedPaths.add(adjustPath(adjustedPath));
        }
        return adjustedPaths;
    }

    private List<Point> adjustPath(List<Point> path) {
        List<Point> adjustedPath = new ArrayList<>();
        int offsetX = 0;
        int offsetY = 0;
        
        for (int i = 0; i < path.size(); i++) {
            Point p = path.get(i);
            adjustedPath.add(new Point(p.x + offsetX, p.y + offsetY));
            
            if (i % 2 == 0) {
                offsetX += 20;
            } else {
                offsetY += 20;
            }
        }
        return adjustedPath;
    }

    public void addFlightPath(List<Point> path) {
        flightPaths.add(path);
        drawPaths();
        repaint();
    }

    public void clearPaths() {
        flightPaths.clear();
        colors.clear();
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(canvas, 0, 0, null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Flight Path Drawer");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            FlightPathDrawer drawer = new FlightPathDrawer();
            
            int frameSize = 1050;
            frame.setSize(frameSize, frameSize);
            frame.setLocationRelativeTo(null); 

            JPanel inputPanel = new JPanel();
            JTextField flightInputField = new JTextField(30);
            JButton addButton = new JButton("Add Flight Path");
            JButton clearButton = new JButton("Clear Paths");

            inputPanel.add(new JLabel("Enter flight coordinates (comma-separated, e.g., 1,1 2,2 3,3):"));
            inputPanel.add(flightInputField);
            inputPanel.add(addButton);
            inputPanel.add(clearButton);
            
            frame.add(drawer, BorderLayout.CENTER);
            frame.add(inputPanel, BorderLayout.SOUTH);
            
            addButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String input = flightInputField.getText();
                    List<Point> path = parsePath(input);
                    drawer.addFlightPath(path);
                    flightInputField.setText(""); 
                }
            });

            clearButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    drawer.clearPaths();
                }
            });

            frame.setVisible(true);
        });
    }

    private static List<Point> parsePath(String pathString) {
        List<Point> path = new ArrayList<>();
        String[] points = pathString.split(" ");
        for (String point : points) {
            String[] coords = point.split(",");
            int x = Integer.parseInt(coords[0]) * 50; 
            int y = Integer.parseInt(coords[1]) * 50; 
            path.add(new Point(x, y));
        }
        return path;
    }
}
