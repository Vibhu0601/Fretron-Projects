import java.util.*;

public class CastlePathFinder {
    static final int N = 8;
    static Set<String> soldiers = new HashSet<>();
    static List<String> paths = new ArrayList<>();
    static int[][] directions = { {0, 1}, {1, 0}, {0, -1}, {-1, 0} }; 
    static String start;
    static String home;
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the number of soldiers:");
        int numSoldiers = scanner.nextInt();
        scanner.nextLine();
        
        System.out.println("Enter coordinates for soldiers (comma-separated, e.g., 1,1 8,9):");
        String[] soldierCoords = scanner.nextLine().split(" ");
        for (String coord : soldierCoords) {
            soldiers.add(coord);
        }
        
        System.out.println("Enter the coordinates for your ‘special’ castle (comma-separated, e.g., 1,2):");
        start = scanner.nextLine();
        home = start;
        
        findPaths(start, new HashSet<>(soldiers), new ArrayList<>(), new HashSet<>());
        
        System.out.println("Thanks. There are " + paths.size() + " unique paths for your ‘special_castle’");
        int pathNum = 1;
        for (String path : paths) {
            System.out.println("Path " + pathNum + ":");
            System.out.println("=======");
            System.out.println(path);
            pathNum++;
        }
        
        scanner.close();
    }
    
    public static void findPaths(String current, Set<String> remainingSoldiers, List<String> currentPath, Set<String> visited) {
        if (remainingSoldiers.isEmpty() && current.equals(home)) {
            paths.add(String.join("\n", currentPath) + "\nArrive " + home);
            return;
        }
        
        String[] pos = current.split(",");
        int x = Integer.parseInt(pos[0]);
        int y = Integer.parseInt(pos[1]);
        
        for (int i = 0; i < 4; i++) {
            int dx = directions[i][0];
            int dy = directions[i][1];
            int nx = x + dx;
            int ny = y + dy;
            
            while (isValid(nx, ny)) {
                String next = nx + "," + ny;
                
                if (remainingSoldiers.contains(next)) {
                    remainingSoldiers.remove(next);
                    currentPath.add("Kill (" + next + "). Turn Left");
                    findPaths(next, remainingSoldiers, new ArrayList<>(currentPath), visited);
                    remainingSoldiers.add(next);
                    currentPath.remove(currentPath.size() - 1);
                }
                
                nx += dx;
                ny += dy;
            }
        }
    }
    
    public static boolean isValid(int x, int y) {
        return x >= 1 && x <= N && y >= 1 && y <= N;
    }
}
