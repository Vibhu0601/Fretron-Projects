import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Apple {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> appleWeights = new ArrayList<>();
        int totalAmount = 100;
        int ramPaid = 50; 
        int shamPaid = 30; 
        int rahimPaid = 20;  
        
        System.out.println("Enter apple weights in grams (-1 to stop):");
        while (true) {
            int weight = scanner.nextInt();
            if (weight == -1) {
                break;
            }
            appleWeights.add(weight);
        }
        
        int totalWeight = appleWeights.stream().mapToInt(Integer::intValue).sum();
        
        double ramTargetWeight = (double) ramPaid / totalAmount * totalWeight;
        double shamTargetWeight = (double) shamPaid / totalAmount * totalWeight;
        double rahimTargetWeight = (double) rahimPaid / totalAmount * totalWeight;
        
        Collections.sort(appleWeights, Comparator.reverseOrder());
        
        ArrayList<Integer> ramApples = new ArrayList<>();
        ArrayList<Integer> shamApples = new ArrayList<>();
        ArrayList<Integer> rahimApples = new ArrayList<>();
        
        double ramAllocated = 0;
        double shamAllocated = 0;
        double rahimAllocated = 0;

        for (int weight : appleWeights) {
            if (ramAllocated + weight <= ramTargetWeight) {
                ramApples.add(weight);
                ramAllocated += weight;
            } else if (shamAllocated + weight <= shamTargetWeight) {
                shamApples.add(weight);
                shamAllocated += weight;
            } else {
                rahimApples.add(weight);
                rahimAllocated += weight;
            }
        }
        
        System.out.println("Distribution Result:");
        System.out.println("Ram: " + ramApples + " (Total: " + ramAllocated + " grams)");
        System.out.println("Sham: " + shamApples + " (Total: " + shamAllocated + " grams)");
        System.out.println("Rahim: " + rahimApples + " (Total: " + rahimAllocated + " grams)");
        
        scanner.close();
    }
}
